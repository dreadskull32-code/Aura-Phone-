# Add project specific ProGuard rules here.
# Release build has minification disabled by default (see app/build.gradle.kts)
# so this file is a placeholder for when you choose to enable it.
