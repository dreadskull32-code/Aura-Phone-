package com.auratv.vibrantglass.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.auratv.vibrantglass.R
import com.auratv.vibrantglass.apps.AppRepository
import com.auratv.vibrantglass.databinding.ActivityApplicationsBinding
import com.auratv.vibrantglass.prefs.PreferencesManager

/** Lets the user pin/unpin apps into the dock — the management side of section 2's dock requirements. */
class ApplicationsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityApplicationsBinding
    private lateinit var prefs: PreferencesManager
    private lateinit var appRepository: AppRepository
    private lateinit var adapter: ApplicationsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityApplicationsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PreferencesManager(this)
        appRepository = AppRepository(this)

        binding.header.screenTitle.text = getString(R.string.menu_applications)
        binding.header.backButton.setOnClickListener { finish() }

        adapter = ApplicationsAdapter(
            isPinned = { prefs.isPinned(it.key) },
            onToggle = { prefs.togglePinned(it.key) },
        )
        binding.applicationsList.layoutManager = LinearLayoutManager(this)
        binding.applicationsList.adapter = adapter
        adapter.submitList(appRepository.loadAllApps())
    }
}
