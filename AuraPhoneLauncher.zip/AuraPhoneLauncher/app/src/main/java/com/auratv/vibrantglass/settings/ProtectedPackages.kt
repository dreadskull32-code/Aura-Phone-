package com.auratv.vibrantglass.settings

/**
 * Best-effort package-name patterns for components the brief explicitly
 * says must never be offered for disabling (section 9): Play services,
 * Play Store, Wi-Fi/Bluetooth, HDMI-CEC, codecs, remote-control input,
 * core Android components and system update services.
 *
 * This is a safety allow/deny list for AURA's OWN UI (which packages it
 * will even show a "manage" action for) — it is not, and cannot be, an
 * OS-level enforcement mechanism. The real enforcement is that a normal
 * app cannot disable another app's components on stock Android at all
 * (see SystemManagerActivity); this list exists so AURA never even
 * routes the user toward doing something risky to these packages via
 * the system App Info screen it deep-links to.
 */
object ProtectedPackages {

    private val protectedSubstrings = listOf(
        "com.google.android.gms", // Play services
        "com.android.vending", // Play Store
        "com.android.wifi",
        "com.android.server.wifi",
        "com.android.bluetooth",
        "com.android.hdmi",
        "hdmi",
        "cec",
        "com.android.providers.media",
        "codec",
        "com.google.android.tv.remote",
        "com.android.tv.remote",
        "com.android.inputmethod",
        "com.android.systemui",
        "android.system",
        "com.android.settings",
        "update",
        "com.sanyo", // manufacturer services — kept out of the disable path by default
    )

    fun isProtected(packageName: String): Boolean {
        val lower = packageName.lowercase()
        if (lower == "android" || lower == "com.android.systemui") return true
        return protectedSubstrings.any { lower.contains(it) }
    }
}
