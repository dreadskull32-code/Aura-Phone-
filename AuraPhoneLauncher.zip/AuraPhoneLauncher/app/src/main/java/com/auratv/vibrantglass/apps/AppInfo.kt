package com.auratv.vibrantglass.apps

import android.graphics.drawable.Drawable

/**
 * Lightweight view-model for one launchable app. [componentName] is kept
 * (not just the package name) because a package can expose several
 * launchable activities; we launch the exact one PackageManager resolved.
 */
data class AppInfo(
    val packageName: String,
    val componentClassName: String,
    val label: String,
    val icon: Drawable?,
) {
    val key: String get() = "$packageName/$componentClassName"
}
