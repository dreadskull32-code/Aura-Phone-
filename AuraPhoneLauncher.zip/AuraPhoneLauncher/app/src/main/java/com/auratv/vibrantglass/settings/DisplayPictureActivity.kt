package com.auratv.vibrantglass.settings

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.auratv.vibrantglass.R
import com.auratv.vibrantglass.databinding.ActivityDisplayPictureBinding

/**
 * Section 6 of the brief, implemented honestly:
 *
 * There is no public AOSP/Android API that lets a third-party app read or
 * set a television panel's contrast, black level, colour temperature,
 * sharpness, gamma, dynamic contrast or noise reduction. Those live in
 * the display controller/TV-chip firmware and are exposed only through
 * each OEM's own Settings app, with no documented public interface —
 * including on Sanyo's Android TV sets, which ship the stock Android TV
 * Settings app for picture controls with no published SDK for it.
 *
 * The ONE real, public, documented control an app can touch is overall
 * screen brightness via Settings.System.SCREEN_BRIGHTNESS — which needs
 * the special WRITE_SETTINGS permission (the user must grant it via a
 * system screen; it cannot be requested in a normal runtime dialog).
 * Whether adjusting that setting visibly changes the TV's backlight
 * varies by device and is NOT guaranteed, which is disclosed in the UI
 * rather than asserted.
 *
 * Everything else here is a clearly labelled shortcut into Android's own
 * Display settings, per the brief's explicit fallback instruction.
 */
class DisplayPictureActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDisplayPictureBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDisplayPictureBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.header.screenTitle.text = getString(R.string.menu_display_picture)
        binding.header.backButton.setOnClickListener { finish() }

        val canWriteSettings = Settings.System.canWrite(this)
        binding.detectionResult.text = if (canWriteSettings) {
            "Detected: this device allows AURA to adjust overall screen brightness (Settings.System.SCREEN_BRIGHTNESS). No API for contrast, colour temperature, sharpness, gamma or dynamic contrast was found on this device or in stock Android."
        } else {
            "No manufacturer picture-control API was found, and AURA does not yet have permission to adjust even basic screen brightness. Tap a preset below to grant it, or use the shortcut to the TV's own picture menu."
        }

        binding.presetExplanation.text = "Presets only change overall screen brightness (the one real, permitted control). Contrast / colour / sharpness are NOT changed — those require the TV's native menu."

        binding.presetCinema.setOnClickListener { applyBrightnessPreset(60) }
        binding.presetVivid.setOnClickListener { applyBrightnessPreset(220) }
        binding.presetNatural.setOnClickListener { applyBrightnessPreset(140) }

        binding.openNativePictureSettings.setOnClickListener {
            openNativeDisplaySettings()
        }
    }

    private fun applyBrightnessPreset(value: Int) {
        if (!Settings.System.canWrite(this)) {
            requestWriteSettingsPermission()
            return
        }
        try {
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, value.coerceIn(0, 255))
        } catch (_: SecurityException) {
            requestWriteSettingsPermission()
        }
    }

    private fun requestWriteSettingsPermission() {
        try {
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
            startActivity(intent)
        } catch (_: Exception) {
            openNativeDisplaySettings()
        }
    }

    private fun openNativeDisplaySettings() {
        val candidates = listOf(
            Settings.ACTION_DISPLAY_SETTINGS,
            Settings.ACTION_SETTINGS,
        )
        for (action in candidates) {
            try {
                startActivity(Intent(action))
                return
            } catch (_: Exception) {
                // Try the next fallback.
            }
        }
    }
}
