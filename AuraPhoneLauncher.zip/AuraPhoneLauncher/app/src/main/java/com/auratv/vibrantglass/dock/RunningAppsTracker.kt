package com.auratv.vibrantglass.dock

import android.app.ActivityManager
import android.content.Context

/**
 * Best-effort "is this package currently running" check.
 *
 * ActivityManager.getRunningAppProcesses() on modern Android (8.0+) only
 * returns the calling app's own process and processes it's directly
 * bound to — NOT a system-wide list of every running app, because
 * Android deliberately removed that visibility from third-party apps
 * for privacy/battery reasons. There is no supported replacement API
 * that gives a launcher full visibility either.
 *
 * So this is intentionally limited and documented as such (per the
 * brief: "do not pretend Android provides unrestricted access to every
 * running application's state"). It mainly reflects processes Android
 * still reports (often just recently-launched ones in the foreground
 * importance bucket), which is enough to light up a "running" dot for
 * the app the user just left, but is not a reliable full list.
 */
class RunningAppsTracker(private val context: Context) {

    fun snapshotRunningPackages(): Set<String> {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return emptySet()
            @Suppress("DEPRECATION")
            val processes = am.runningAppProcesses ?: return emptySet()
            processes
                .filter { it.importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE }
                .flatMap { it.pkgList?.toList() ?: emptyList() }
                .toSet()
        } catch (_: Exception) {
            emptySet()
        }
    }
}
