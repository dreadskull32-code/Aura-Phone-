package com.auratv.vibrantglass.wallpaper

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.util.AttributeSet
import android.view.View
import androidx.core.graphics.drawable.toBitmap

/**
 * Renders the launcher's in-app wallpaper (NOT the system wallpaper — the
 * brief is explicit that wallpaper changes must stay inside the launcher
 * and never interrupt navigation, so this is just a background View, not
 * android.app.WallpaperManager). Applies blur, a darkness overlay, a
 * saturation/colour-intensity adjustment and an optional gradient overlay,
 * and crossfades between the old and new bitmap when the wallpaper changes.
 *
 * Blur: true backdrop blur (RenderEffect) is only available on API 31+.
 * Below that, blur is approximated by downscaling and re-upscaling the
 * bitmap (a cheap box-blur substitute) — not identical quality, but
 * lightweight, which the brief prioritises for older TV hardware.
 */
class WallpaperView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    private var currentBitmap: Bitmap? = null
    private var previousBitmap: Bitmap? = null
    private var crossfadeProgress = 1f // 1 = fully on currentBitmap

    private var blurPercent = 0
    private var darknessPercent = 20
    private var saturationPercent = 100
    private var gradientEnabled = false

    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val overlayPaint = Paint()
    private val fallback = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor("#FF080812"), Color.parseColor("#FF14102B"), Color.parseColor("#FF080812"))
    )

    fun setConfig(blur: Int, darkness: Int, saturation: Int, gradient: Boolean) {
        blurPercent = blur.coerceIn(0, 100)
        darknessPercent = darkness.coerceIn(0, 100)
        saturationPercent = saturation.coerceIn(0, 100)
        gradientEnabled = gradient
        applyColorFilter()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) applyRenderEffectBlur()
        invalidate()
    }

    /** Loads [uri] (or clears to the default gradient if null) and crossfades to it. */
    fun setWallpaperUri(uri: Uri?) {
        if (uri == null) {
            previousBitmap = currentBitmap
            currentBitmap = null
            startCrossfade()
            return
        }
        try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val original = android.graphics.BitmapFactory.decodeStream(stream) ?: return
                previousBitmap = currentBitmap
                currentBitmap = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S && blurPercent > 0) {
                    approximateBlur(original, blurPercent)
                } else {
                    original
                }
                startCrossfade()
            }
        } catch (_: Exception) {
            // Leave whatever was already showing; never crash the home screen
            // over a bad/revoked content URI.
        }
    }

    private fun startCrossfade() {
        crossfadeProgress = 0f
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450
            addUpdateListener {
                crossfadeProgress = it.animatedValue as Float
                invalidate()
            }
        }.start()
    }

    private fun applyColorFilter() {
        val sat = saturationPercent / 100f
        val matrix = ColorMatrix().apply { setSaturation(sat) }
        bitmapPaint.colorFilter = ColorMatrixColorFilter(matrix)
    }

    private fun applyRenderEffectBlur() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val radius = (blurPercent / 100f * 25f).coerceAtLeast(0.01f)
            setRenderEffect(
                if (blurPercent > 0) {
                    RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP)
                } else null
            )
        }
    }

    /** Cheap blur substitute for API < 31: downscale then upscale. */
    private fun approximateBlur(src: Bitmap, percent: Int): Bitmap {
        if (percent <= 0) return src
        val scale = (1f - (percent / 100f) * 0.9f).coerceAtLeast(0.05f)
        val w = (src.width * scale).toInt().coerceAtLeast(1)
        val h = (src.height * scale).toInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        return Bitmap.createScaledBitmap(small, src.width, src.height, true)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val bmp = currentBitmap
        if (bmp == null) {
            fallback.setBounds(0, 0, width, height)
            fallback.draw(canvas)
        } else {
            drawBitmapCover(canvas, bmp, bitmapPaint, if (previousBitmap == null) 1f else crossfadeProgress)
            previousBitmap?.let { prev ->
                if (crossfadeProgress < 1f) {
                    drawBitmapCover(canvas, prev, bitmapPaint, 1f - crossfadeProgress)
                }
            }
        }

        if (darknessPercent > 0) {
            overlayPaint.color = Color.argb((darknessPercent * 2.2f).toInt().coerceIn(0, 255), 0, 0, 0)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), overlayPaint)
        }

        if (gradientEnabled) {
            val gradient = LinearGradient(
                0f, 0f, 0f, height.toFloat(),
                Color.TRANSPARENT, Color.parseColor("#AA080812"),
                Shader.TileMode.CLAMP
            )
            overlayPaint.shader = gradient
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), overlayPaint)
            overlayPaint.shader = null
        }
    }

    /** Centre-crop draw so any aspect-ratio photo fills a 16:9-ish TV screen without distortion. */
    private fun drawBitmapCover(canvas: Canvas, bitmap: Bitmap, paint: Paint, alpha: Float) {
        if (width == 0 || height == 0) return
        val viewRatio = width.toFloat() / height.toFloat()
        val bmpRatio = bitmap.width.toFloat() / bitmap.height.toFloat()

        val srcRect = if (bmpRatio > viewRatio) {
            val newWidth = (bitmap.height * viewRatio).toInt()
            val left = (bitmap.width - newWidth) / 2
            android.graphics.Rect(left, 0, left + newWidth, bitmap.height)
        } else {
            val newHeight = (bitmap.width / viewRatio).toInt()
            val top = (bitmap.height - newHeight) / 2
            android.graphics.Rect(0, top, bitmap.width, top + newHeight)
        }
        val dstRect = android.graphics.Rect(0, 0, width, height)
        paint.alpha = (alpha * 255).toInt().coerceIn(0, 255)
        canvas.drawBitmap(bitmap, srcRect, dstRect, paint)
        paint.alpha = 255
    }
}
