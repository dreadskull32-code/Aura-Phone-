package com.auratv.vibrantglass.prefs

import android.content.Context
import android.net.Uri
import org.json.JSONArray

/**
 * Single SharedPreferences-backed store for everything the launcher needs
 * to remember between launches: pinned dock apps, interface/animation
 * settings and wallpaper configuration. Kept as one small class per the
 * "persistent user preferences" requirement rather than scattering raw
 * SharedPreferences calls through the UI code.
 */
class PreferencesManager(context: Context) {

    private val prefs = context.getSharedPreferences("aura_tv_prefs", Context.MODE_PRIVATE)

    // ---- Dock ----

    fun getPinnedApps(): List<String> {
        val raw = prefs.getString(KEY_PINNED_APPS, null) ?: return DEFAULT_PINNED
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (_: Exception) {
            DEFAULT_PINNED
        }
    }

    fun setPinnedApps(packageKeys: List<String>) {
        val arr = JSONArray()
        packageKeys.forEach { arr.put(it) }
        prefs.edit().putString(KEY_PINNED_APPS, arr.toString()).apply()
    }

    fun isPinned(key: String): Boolean = getPinnedApps().contains(key)

    fun togglePinned(key: String) {
        val current = getPinnedApps().toMutableList()
        if (current.contains(key)) current.remove(key) else current.add(key)
        setPinnedApps(current)
    }

    // ---- Interface / animation ----

    fun getAnimationSpeedMultiplier(): Float = prefs.getFloat(KEY_ANIM_SPEED, 1.0f)
    fun setAnimationSpeedMultiplier(value: Float) = prefs.edit().putFloat(KEY_ANIM_SPEED, value).apply()

    fun isReducedMotion(): Boolean = prefs.getBoolean(KEY_REDUCED_MOTION, false)
    fun setReducedMotion(enabled: Boolean) = prefs.edit().putBoolean(KEY_REDUCED_MOTION, enabled).apply()

    fun isDockMagnificationEnabled(): Boolean = prefs.getBoolean(KEY_DOCK_MAGNIFY, true)
    fun setDockMagnificationEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_DOCK_MAGNIFY, enabled).apply()

    fun isFocusGlowEnabled(): Boolean = prefs.getBoolean(KEY_FOCUS_GLOW, true)
    fun setFocusGlowEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_FOCUS_GLOW, enabled).apply()

    // ---- Wallpaper ----

    fun getWallpaperUri(): Uri? = prefs.getString(KEY_WALLPAPER_URI, null)?.let { Uri.parse(it) }
    fun setWallpaperUri(uri: Uri?) = prefs.edit().putString(KEY_WALLPAPER_URI, uri?.toString()).apply()

    fun getBlurPercent(): Int = prefs.getInt(KEY_BLUR, 0)
    fun setBlurPercent(value: Int) = prefs.edit().putInt(KEY_BLUR, value).apply()

    fun getDarknessPercent(): Int = prefs.getInt(KEY_DARKNESS, 20)
    fun setDarknessPercent(value: Int) = prefs.edit().putInt(KEY_DARKNESS, value).apply()

    fun getSaturationPercent(): Int = prefs.getInt(KEY_SATURATION, 100)
    fun setSaturationPercent(value: Int) = prefs.edit().putInt(KEY_SATURATION, value).apply()

    fun isGradientOverlayEnabled(): Boolean = prefs.getBoolean(KEY_GRADIENT_OVERLAY, false)
    fun setGradientOverlayEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_GRADIENT_OVERLAY, enabled).apply()

    // ---- System Manager change history (backup of original enabled-state) ----

    fun recordOriginalEnabledState(packageName: String, wasEnabled: Boolean) {
        if (prefs.contains(KEY_ORIGINAL_STATE_PREFIX + packageName)) return // only ever store the *first* observed state
        prefs.edit().putBoolean(KEY_ORIGINAL_STATE_PREFIX + packageName, wasEnabled).apply()
    }

    fun getOriginalEnabledState(packageName: String): Boolean? {
        return if (prefs.contains(KEY_ORIGINAL_STATE_PREFIX + packageName)) {
            prefs.getBoolean(KEY_ORIGINAL_STATE_PREFIX + packageName, true)
        } else null
    }

    fun appendChangeHistory(entry: String) {
        val existing = prefs.getString(KEY_CHANGE_HISTORY, "") ?: ""
        val updated = (listOf(entry) + existing.split("\n").filter { it.isNotBlank() }).take(100)
        prefs.edit().putString(KEY_CHANGE_HISTORY, updated.joinToString("\n")).apply()
    }

    fun getChangeHistory(): List<String> {
        return (prefs.getString(KEY_CHANGE_HISTORY, "") ?: "").split("\n").filter { it.isNotBlank() }
    }

    companion object {
        private const val KEY_PINNED_APPS = "pinned_apps"
        private const val KEY_ANIM_SPEED = "anim_speed"
        private const val KEY_REDUCED_MOTION = "reduced_motion"
        private const val KEY_DOCK_MAGNIFY = "dock_magnify"
        private const val KEY_FOCUS_GLOW = "focus_glow"
        private const val KEY_WALLPAPER_URI = "wallpaper_uri"
        private const val KEY_BLUR = "wallpaper_blur"
        private const val KEY_DARKNESS = "wallpaper_darkness"
        private const val KEY_SATURATION = "wallpaper_saturation"
        private const val KEY_GRADIENT_OVERLAY = "wallpaper_gradient"
        private const val KEY_ORIGINAL_STATE_PREFIX = "orig_state_"
        private const val KEY_CHANGE_HISTORY = "change_history"
        private val DEFAULT_PINNED = emptyList<String>()
    }
}
