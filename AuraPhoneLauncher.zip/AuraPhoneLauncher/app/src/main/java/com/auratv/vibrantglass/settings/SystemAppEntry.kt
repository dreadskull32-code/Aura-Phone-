package com.auratv.vibrantglass.settings

import android.graphics.drawable.Drawable

data class SystemAppEntry(
    val packageName: String,
    val label: String,
    val icon: Drawable?,
    val isEnabled: Boolean,
    val isSystemApp: Boolean,
    val isProtected: Boolean,
)
