package com.auratv.vibrantglass.settings

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.auratv.vibrantglass.R

class SystemAppAdapter(
    private val onManage: (SystemAppEntry) -> Unit,
) : RecyclerView.Adapter<SystemAppAdapter.ViewHolder>() {

    private val items = mutableListOf<SystemAppEntry>()

    fun submitList(newItems: List<SystemAppEntry>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_system_app, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = items[position]
        holder.icon.setImageDrawable(entry.icon)
        holder.name.text = entry.label
        holder.pkg.text = entry.packageName
        holder.status.text = buildString {
            append(if (entry.isEnabled) "Enabled" else "Disabled")
            if (entry.isSystemApp) append(" · System")
            if (entry.isProtected) append(" · Protected")
        }
        holder.manageButton.isEnabled = !entry.isProtected
        holder.manageButton.alpha = if (entry.isProtected) 0.4f else 1f
        holder.manageButton.text = holder.itemView.context.getString(
            if (entry.isProtected) R.string.protected_app_warning else R.string.open_app_settings
        ).let { if (entry.isProtected) "Protected" else it }
        holder.manageButton.setOnClickListener {
            if (!entry.isProtected) onManage(entry)
        }
    }

    override fun getItemCount(): Int = items.size

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.sysAppIcon)
        val name: TextView = view.findViewById(R.id.sysAppName)
        val pkg: TextView = view.findViewById(R.id.sysAppPackage)
        val status: TextView = view.findViewById(R.id.sysAppStatus)
        val manageButton: Button = view.findViewById(R.id.sysAppManageButton)
    }
}
