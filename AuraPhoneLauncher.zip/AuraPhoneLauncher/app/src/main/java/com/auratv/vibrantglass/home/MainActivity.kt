package com.auratv.vibrantglass.home

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.auratv.vibrantglass.R
import com.auratv.vibrantglass.apps.AppAdapter
import com.auratv.vibrantglass.apps.AppInfo
import com.auratv.vibrantglass.apps.AppRepository
import com.auratv.vibrantglass.databinding.ActivityMainBinding
import com.auratv.vibrantglass.dock.DockAdapter
import com.auratv.vibrantglass.dock.RunningAppsTracker
import com.auratv.vibrantglass.monitor.SystemMonitor
import com.auratv.vibrantglass.panel.SideMenuAdapter
import com.auratv.vibrantglass.panel.SideMenuItem
import com.auratv.vibrantglass.prefs.PreferencesManager
import com.auratv.vibrantglass.settings.AboutActivity
import com.auratv.vibrantglass.settings.ApplicationsActivity
import com.auratv.vibrantglass.settings.DisplayPictureActivity
import com.auratv.vibrantglass.settings.InterfaceSettingsActivity
import com.auratv.vibrantglass.settings.PrivacyActivity
import com.auratv.vibrantglass.settings.SystemManagerActivity
import com.auratv.vibrantglass.settings.TvSettingsActivity
import com.auratv.vibrantglass.settings.WallpaperActivity

/**
 * Home screen + hamburger panel host, per sections 2 and 3 of the brief.
 * Everything else (actual settings content) lives in its own Activity,
 * reached only through the side panel's menu, never from the home screen
 * directly.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PreferencesManager
    private lateinit var appRepository: AppRepository
    private lateinit var systemMonitor: SystemMonitor
    private lateinit var runningAppsTracker: RunningAppsTracker

    private lateinit var appAdapter: AppAdapter
    private lateinit var dockAdapter: DockAdapter

    private var allApps: List<AppInfo> = emptyList()
    private var sidePanelOpen = false

    private val uiHandler = Handler(Looper.getMainLooper())
    private val monitorRunnable = object : Runnable {
        override fun run() {
            refreshSystemIndicators()
            refreshRunningIndicators()
            // 5s cadence: frequent enough to feel "live" without polling so
            // hard it costs battery/CPU on limited TV hardware (perf section 13).
            uiHandler.postDelayed(this, 5000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Keeps the home screen awake while visible; TV boxes otherwise
        // dim/sleep the same as a phone would.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefs = PreferencesManager(this)
        appRepository = AppRepository(this)
        systemMonitor = SystemMonitor(this)
        runningAppsTracker = RunningAppsTracker(this)

        setupAppGrid()
        setupDock()
        setupSidePanel()
        setupWallpaper()
        setupBackPress()

        binding.hamburgerButton.setOnClickListener { toggleSidePanel() }

        loadApps()
    }

    override fun onResume() {
        super.onResume()
        loadApps() // app list / pin order can change after visiting Applications/System Manager
        applyAnimationPrefs()
        dockAdapter.magnificationEnabled = prefs.isDockMagnificationEnabled()
        setupWallpaper() // cheap no-op redraw if nothing changed; picks up Wallpaper-screen edits
        monitorRunnable.run()
    }

    override fun onPause() {
        super.onPause()
        uiHandler.removeCallbacks(monitorRunnable)
    }

    // ---------------------------------------------------------------
    // App grid
    // ---------------------------------------------------------------

    private fun setupAppGrid() {
        appAdapter = AppAdapter(
            onClick = { launchApp(it) },
            onLongPress = { app -> prefs.togglePinned(app.key); refreshDock() },
        )
        applyAnimationPrefs()

        // Resolution adaptation (section 7): span count follows the actual
        // detected display width rather than a hardcoded "4 columns",
        // required so the grid can't look impossibly cramped on a 720p set
        // or impossibly sparse on 4K while using the same resource files.
        binding.appGrid.layoutManager = GridLayoutManager(this, computeRowCount(), GridLayoutManager.HORIZONTAL, false)
        binding.appGrid.adapter = appAdapter
    }

    /**
     * Phone layout: the grid scrolls sideways like Android TV rows, so the
     * "span count" is the number of stacked rows that fit the screen height
     * (more rows in portrait, one or two in landscape).
     */
    private fun computeRowCount(): Int {
        val metrics = resources.displayMetrics
        val d = metrics.density
        val tileHeight = (100 * d) + (resources.getDimension(R.dimen.tile_margin) * 2)
        val reserved = resources.getDimension(R.dimen.top_bar_height) +
            resources.getDimension(R.dimen.dock_height) + (24 * d)
        val rows = ((metrics.heightPixels - reserved) / tileHeight).toInt()
        return rows.coerceIn(1, 5)
    }

    private fun loadApps() {
        allApps = appRepository.loadAllApps()
        appAdapter.submitList(allApps)
        refreshDock()
    }

    private fun launchApp(app: AppInfo) {
        val intent = appRepository.launchIntentFor(app) ?: return
        try {
            startActivity(intent)
        } catch (_: Exception) {
            // Package may have been uninstalled or become temporarily
            // unavailable since the grid was built; fail quietly and let
            // the next onResume's loadApps() drop it from the list.
        }
    }

    // ---------------------------------------------------------------
    // Dock
    // ---------------------------------------------------------------

    private fun setupDock() {
        dockAdapter = DockAdapter(
            onClick = { launchApp(it) },
            onLongPress = { app -> prefs.togglePinned(app.key); refreshDock() },
        )
        dockAdapter.magnificationEnabled = prefs.isDockMagnificationEnabled()
        binding.dockList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.dockList.adapter = dockAdapter
    }

    private fun refreshDock() {
        val pinnedKeys = prefs.getPinnedApps()
        val pinnedApps = pinnedKeys.mapNotNull { key -> allApps.firstOrNull { it.key == key } }
        dockAdapter.submitList(pinnedApps)
        refreshRunningIndicators()
    }

    private fun refreshRunningIndicators() {
        if (!::dockAdapter.isInitialized) return
        dockAdapter.updateRunning(runningAppsTracker.snapshotRunningPackages())
    }

    // ---------------------------------------------------------------
    // System monitor chips
    // ---------------------------------------------------------------

    private fun refreshSystemIndicators() {
        val ram = systemMonitor.readRam()
        binding.ramText.text = if (ram != null) {
            "${SystemMonitor.formatBytes(ram.usedBytes)} / ${SystemMonitor.formatBytes(ram.totalBytes)} (${ram.usedPercent}%)"
        } else {
            getString(R.string.ram_unavailable)
        }

        val storage = systemMonitor.readStorage()
        binding.storageText.text = if (storage != null) {
            "${SystemMonitor.formatBytes(storage.usedBytes)} / ${SystemMonitor.formatBytes(storage.totalBytes)} (${storage.usedPercent}%)"
        } else {
            getString(R.string.storage_unavailable)
        }
    }

    // ---------------------------------------------------------------
    // Side panel (hamburger menu)
    // ---------------------------------------------------------------

    private fun setupSidePanel() {
        binding.sideMenuList.layoutManager = LinearLayoutManager(this)
        binding.sideMenuList.adapter = SideMenuAdapter { item -> onSideMenuItemSelected(item) }
        binding.scrim.setOnClickListener { closeSidePanel() }
    }

    private fun onSideMenuItemSelected(item: SideMenuItem) {
        closeSidePanel()
        val destination: Class<*>? = when (item) {
            SideMenuItem.HOME -> null
            SideMenuItem.APPLICATIONS -> ApplicationsActivity::class.java
            SideMenuItem.DISPLAY_PICTURE -> DisplayPictureActivity::class.java
            SideMenuItem.TV_SETTINGS -> TvSettingsActivity::class.java
            SideMenuItem.INTERFACE_SETTINGS -> InterfaceSettingsActivity::class.java
            SideMenuItem.WALLPAPER -> WallpaperActivity::class.java
            SideMenuItem.PRIVACY -> PrivacyActivity::class.java
            SideMenuItem.SYSTEM_MANAGER -> SystemManagerActivity::class.java
            SideMenuItem.ABOUT -> AboutActivity::class.java
        }
        destination?.let { startActivity(Intent(this, it)) }
    }

    private fun toggleSidePanel() {
        if (sidePanelOpen) closeSidePanel() else openSidePanel()
    }

    private fun openSidePanel() {
        sidePanelOpen = true
        binding.sidePanel.visibility = android.view.View.VISIBLE
        binding.sidePanel.translationX = binding.sidePanel.width.takeIf { it > 0 }
            ?.toFloat() ?: resources.getDimension(R.dimen.side_panel_width)
        binding.scrim.visibility = android.view.View.VISIBLE
        binding.scrim.alpha = 0f
        binding.sidePanel.animate().translationX(0f).setDuration(animDuration(260)).withEndAction {
            binding.sideMenuList.requestFocus()
        }.start()
        binding.scrim.animate().alpha(1f).setDuration(animDuration(260)).start()
    }

    private fun closeSidePanel() {
        sidePanelOpen = false
        binding.sidePanel.animate().translationX(binding.sidePanel.width.toFloat()).setDuration(animDuration(220)).withEndAction {
            binding.sidePanel.visibility = android.view.View.INVISIBLE
        }.start()
        binding.scrim.animate().alpha(0f).setDuration(animDuration(220)).withEndAction {
            binding.scrim.visibility = android.view.View.GONE
        }.start()
        binding.hamburgerButton.requestFocus()
    }

    private fun setupBackPress() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (sidePanelOpen) {
                    closeSidePanel()
                } else {
                    // This activity IS Home; there's nowhere "back" to go,
                    // matching standard Android TV launcher behaviour.
                }
            }
        })
    }

    // ---------------------------------------------------------------
    // Wallpaper + animation preferences
    // ---------------------------------------------------------------

    private fun setupWallpaper() {
        val p = prefs
        binding.wallpaperView.setConfig(p.getBlurPercent(), p.getDarknessPercent(), p.getSaturationPercent(), p.isGradientOverlayEnabled())
        binding.wallpaperView.setWallpaperUri(p.getWallpaperUri())
    }

    private fun applyAnimationPrefs() {
        val speed = if (prefs.isReducedMotion()) 0f else prefs.getAnimationSpeedMultiplier()
        appAdapter.animationDurationMs = if (speed <= 0f) 0L else (150L / speed).toLong().coerceAtMost(600L)
        appAdapter.focusScale = if (prefs.isFocusGlowEnabled()) resources.getDimension(R.dimen.focus_scale_tile) else 1.03f
    }

    private fun animDuration(base: Long): Long {
        val speed = if (prefs.isReducedMotion()) 0f else prefs.getAnimationSpeedMultiplier()
        return if (speed <= 0f) 0L else (base / speed).toLong()
    }
}
