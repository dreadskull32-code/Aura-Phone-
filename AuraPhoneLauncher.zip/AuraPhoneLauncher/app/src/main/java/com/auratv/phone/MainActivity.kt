package com.auratv.phone

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * AURA Phone: a TV-style launcher for phones. Apps sit in horizontally
 * scrolling rows over the system wallpaper. Tap to open, long-press for
 * the app's info / uninstall screen.
 */
class MainActivity : Activity() {

    class AppItem(
        val label: String,
        val pkg: String,
        val cls: String,
        val icon: Drawable
    )

    private val apps = ArrayList<AppItem>()
    private lateinit var clock: TextView
    private lateinit var dateText: TextView
    private lateinit var list: RecyclerView
    private val adapter = AppAdapter()
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 15000L)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#B3080A14"))

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dp(24), dp(56), dp(24), dp(24))

        clock = TextView(this)
        clock.textSize = 54f
        clock.setTextColor(Color.WHITE)

        dateText = TextView(this)
        dateText.textSize = 16f
        dateText.setTextColor(Color.parseColor("#B0FFFFFF"))

        list = RecyclerView(this)
        list.layoutManager = GridLayoutManager(this, 2, RecyclerView.HORIZONTAL, false)
        list.adapter = adapter
        list.clipToPadding = false
        list.setPadding(0, dp(24), 0, 0)

        column.addView(clock)
        column.addView(dateText)
        column.addView(
            list,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )
        root.addView(
            column,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Home pressed while already open: scroll back to the start.
        if (::list.isInitialized) list.scrollToPosition(0)
    }

    override fun onBackPressed() {
        // A launcher stays put on Back.
    }

    private fun updateClock() {
        val now = Date()
        clock.text = SimpleDateFormat("h:mm", Locale.getDefault()).format(now)
        dateText.text = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(now)
    }

    private fun loadApps() {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN)
        query.addCategory(Intent.CATEGORY_LAUNCHER)
        val found: List<ResolveInfo> = pm.queryIntentActivities(query, 0)
        apps.clear()
        for (ri in found) {
            val info = ri.activityInfo
            if (info.packageName == packageName) continue
            apps.add(
                AppItem(
                    ri.loadLabel(pm).toString(),
                    info.packageName,
                    info.name,
                    ri.loadIcon(pm)
                )
            )
        }
        apps.sortBy { it.label.lowercase(Locale.getDefault()) }
        adapter.notifyDataSetChanged()
    }

    private fun launch(item: AppItem) {
        try {
            val i = Intent(Intent.ACTION_MAIN)
            i.addCategory(Intent.CATEGORY_LAUNCHER)
            i.setClassName(item.pkg, item.cls)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(i)
        } catch (e: Exception) {
            // App disappeared or can't be opened; ignore.
        }
    }

    private fun openInfo(item: AppItem) {
        try {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:" + item.pkg)
            startActivity(i)
        } catch (e: Exception) {
            // Ignore.
        }
    }

    class Holder(
        val tile: LinearLayout,
        val icon: ImageView,
        val label: TextView
    ) : RecyclerView.ViewHolder(tile)

    inner class AppAdapter : RecyclerView.Adapter<Holder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val tile = LinearLayout(this@MainActivity)
            tile.orientation = LinearLayout.VERTICAL
            tile.gravity = Gravity.CENTER_HORIZONTAL
            tile.setPadding(dp(8), dp(14), dp(8), dp(10))
            tile.isFocusable = true
            tile.isClickable = true

            val bg = GradientDrawable()
            bg.cornerRadius = dp(20).toFloat()
            bg.setColor(Color.parseColor("#26FFFFFF"))
            bg.setStroke(dp(1), Color.parseColor("#33FFFFFF"))
            tile.background = bg

            val lp = RecyclerView.LayoutParams(dp(92), ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(6), dp(6), dp(6), dp(6))
            tile.layoutParams = lp

            val icon = ImageView(this@MainActivity)
            icon.layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))

            val label = TextView(this@MainActivity)
            label.textSize = 12f
            label.maxLines = 1
            label.gravity = Gravity.CENTER
            label.setTextColor(Color.WHITE)
            label.setPadding(0, dp(8), 0, 0)
            label.ellipsize = android.text.TextUtils.TruncateAt.END

            tile.addView(icon)
            tile.addView(
                label,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
            return Holder(tile, icon, label)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val item = apps[position]
            holder.icon.setImageDrawable(item.icon)
            holder.label.text = item.label
            holder.tile.setOnClickListener { launch(item) }
            holder.tile.setOnLongClickListener {
                openInfo(item)
                true
            }
            holder.tile.setOnFocusChangeListener { v: View, hasFocus: Boolean ->
                v.scaleX = if (hasFocus) 1.08f else 1f
                v.scaleY = if (hasFocus) 1.08f else 1f
            }
        }

        override fun getItemCount(): Int = apps.size
    }
}
