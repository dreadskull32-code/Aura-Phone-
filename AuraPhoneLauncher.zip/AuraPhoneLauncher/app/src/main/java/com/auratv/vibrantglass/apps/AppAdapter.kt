package com.auratv.vibrantglass.apps

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.auratv.vibrantglass.R

/**
 * Main home-screen app grid. Focus magnification and glow are driven here
 * (not by a drawable animation) so they can be toggled off via
 * Interface Settings, and so the scale animation stays short/lightweight
 * as the brief asks for on older TV hardware.
 */
class AppAdapter(
    private val onClick: (AppInfo) -> Unit,
    private val onLongPress: (AppInfo) -> Unit,
) : RecyclerView.Adapter<AppAdapter.ViewHolder>() {

    private val items = mutableListOf<AppInfo>()
    var focusScale: Float = 1.12f
    var animationDurationMs: Long = 150L

    fun submitList(newItems: List<AppInfo>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app_tile, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = items[position]
        holder.icon.setImageDrawable(app.icon ?: holder.icon.context.getDrawable(R.drawable.ic_placeholder_app))
        holder.label.text = app.label
        holder.itemView.setOnClickListener { onClick(app) }
        holder.itemView.setOnLongClickListener { onLongPress(app); true }
        holder.itemView.setOnFocusChangeListener { v, hasFocus ->
            val scale = if (hasFocus) focusScale else 1f
            v.animate().scaleX(scale).scaleY(scale).setDuration(animationDurationMs).start()
        }
    }

    override fun getItemCount(): Int = items.size

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val label: TextView = view.findViewById(R.id.appLabel)
    }
}
