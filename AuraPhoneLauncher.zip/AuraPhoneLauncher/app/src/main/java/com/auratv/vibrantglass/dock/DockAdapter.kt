package com.auratv.vibrantglass.dock

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.auratv.vibrantglass.R
import com.auratv.vibrantglass.apps.AppInfo

/**
 * Floating dock. Shows pinned apps (always present) plus, when
 * [DockAdapter.showRunningIndicator] detects a package in
 * [runningPackageNames], a small dot underneath — Android gives a
 * launcher no reliable "list every running app" API on modern versions,
 * so "running" here means "has a live/recently-visible task", read via
 * ActivityManager.getRunningAppProcesses (limited to the launcher's own
 * importance bucket on API 26+) — a best-effort signal, not a guarantee,
 * exactly as the brief's "where technically possible" qualifier expects.
 */
class DockAdapter(
    private val onClick: (AppInfo) -> Unit,
    private val onLongPress: (AppInfo) -> Unit,
) : RecyclerView.Adapter<DockAdapter.ViewHolder>() {

    private val items = mutableListOf<AppInfo>()
    private var runningPackageNames: Set<String> = emptySet()
    var magnificationEnabled: Boolean = true
    var focusScale: Float = 1.35f

    fun submitList(newItems: List<AppInfo>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    fun updateRunning(running: Set<String>) {
        runningPackageNames = running
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_dock_app, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = items[position]
        holder.icon.setImageDrawable(app.icon ?: holder.icon.context.getDrawable(R.drawable.ic_placeholder_app))
        holder.runningDot.visibility = if (runningPackageNames.contains(app.packageName)) View.VISIBLE else View.INVISIBLE
        holder.itemView.setOnClickListener { onClick(app) }
        holder.itemView.setOnLongClickListener { onLongPress(app); true }
        holder.itemView.setOnFocusChangeListener { v, hasFocus ->
            val scale = if (hasFocus && magnificationEnabled) focusScale else 1f
            v.animate().scaleX(scale).scaleY(scale).translationY(if (hasFocus && magnificationEnabled) -10f else 0f).setDuration(140).start()
        }
    }

    override fun getItemCount(): Int = items.size

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.dockIcon)
        val runningDot: View = view.findViewById(R.id.runningDot)
    }
}
