package com.auratv.vibrantglass.monitor

import android.app.ActivityManager
import android.content.Context
import android.os.Environment
import android.os.StatFs
import java.util.Locale

data class RamSnapshot(val totalBytes: Long, val availableBytes: Long) {
    val usedBytes: Long get() = (totalBytes - availableBytes).coerceAtLeast(0)
    val usedPercent: Int get() = if (totalBytes <= 0) 0 else ((usedBytes * 100) / totalBytes).toInt()
}

data class StorageSnapshot(val totalBytes: Long, val availableBytes: Long) {
    val usedBytes: Long get() = (totalBytes - availableBytes).coerceAtLeast(0)
    val usedPercent: Int get() = if (totalBytes <= 0) 0 else ((usedBytes * 100) / totalBytes).toInt()
}

/**
 * Reads real RAM and internal-storage figures from supported Android APIs
 * only (ActivityManager.MemoryInfo, StatFs). Per the brief, if a value
 * cannot be reliably obtained this returns null rather than a fabricated
 * number — the UI layer is responsible for showing an "unavailable" state
 * in that case instead of a fake one.
 */
class SystemMonitor(private val context: Context) {

    fun readRam(): RamSnapshot? {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return null
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            if (info.totalMem <= 0) null else RamSnapshot(totalBytes = info.totalMem, availableBytes = info.availMem)
        } catch (_: Exception) {
            null
        }
    }

    fun readStorage(): StorageSnapshot? {
        return try {
            val path = Environment.getDataDirectory()
            val stat = StatFs(path.path)
            val total = stat.blockCountLong * stat.blockSizeLong
            val available = stat.availableBlocksLong * stat.blockSizeLong
            if (total <= 0) null else StorageSnapshot(totalBytes = total, availableBytes = available)
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        fun formatBytes(bytes: Long): String {
            if (bytes <= 0) return "0 GB"
            val gb = bytes / (1024.0 * 1024.0 * 1024.0)
            return String.format(Locale.US, "%.1f GB", gb)
        }
    }
}
