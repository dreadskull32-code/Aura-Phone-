package com.auratv.vibrantglass.settings

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.auratv.vibrantglass.R
import com.auratv.vibrantglass.databinding.ActivitySystemManagerBinding
import com.auratv.vibrantglass.prefs.PreferencesManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Section 9 of the brief, implemented within real platform limits.
 *
 * IMPORTANT, and disclosed in the UI (R.string.system_manager_disclaimer):
 * a normal third-party app CANNOT call
 * PackageManager.setApplicationEnabledSetting() on another app's
 * components on stock, non-rooted Android — that call requires either
 * the CHANGE_COMPONENT_ENABLED_STATE signature permission (system apps
 * only), device-owner/profile-owner status, or being run through `adb
 * shell pm disable-user`. There is no safe, permission-grantable path for
 * a sideloaded launcher to flip that switch itself.
 *
 * So this screen does exactly what IS possible and safe:
 *   - Lists every installed app (user + system) with its real current
 *     enabled/disabled state, using PackageManager — no fabricated data.
 *   - Flags packages that must never be touched (ProtectedPackages).
 *   - Deep-links to that package's native "App info" screen
 *     (ACTION_APPLICATION_DETAILS_SETTINGS), where Android's own OS
 *     exposes a Disable/Force-stop button directly, if and only if the
 *     OS itself permits it for that package. That is the actual "safe
 *     alternative" the brief asks for when a feature needs elevated
 *     access.
 *   - Tracks each package's first-observed enabled state as a backup,
 *     and appends a human change-history line whenever a later read
 *     shows that state changed (e.g. because the user disabled it from
 *     the App info screen we sent them to, or via ADB) — a real record,
 *     not a log of actions AURA itself does not actually perform.
 */
class SystemManagerActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySystemManagerBinding
    private lateinit var prefs: PreferencesManager
    private lateinit var adapter: SystemAppAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySystemManagerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PreferencesManager(this)

        binding.header.screenTitle.text = getString(R.string.menu_system_manager)
        binding.header.backButton.setOnClickListener { finish() }

        adapter = SystemAppAdapter { entry -> openAppInfo(entry.packageName) }
        binding.systemAppList.layoutManager = LinearLayoutManager(this)
        binding.systemAppList.adapter = adapter

        loadApps()
    }

    override fun onResume() {
        super.onResume()
        // Re-check state in case the user just came back from the native
        // App info screen having disabled/enabled something there.
        loadApps()
    }

    private fun loadApps() {
        binding.loadingSpinner.visibility = android.view.View.VISIBLE
        lifecycleScope.launch {
            val entries = withContext(Dispatchers.IO) { buildEntries() }
            adapter.submitList(entries)
            binding.loadingSpinner.visibility = android.view.View.GONE
        }
    }

    private fun buildEntries(): List<SystemAppEntry> {
        val pm = packageManager
        val apps = try {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
        } catch (_: Exception) {
            emptyList()
        }

        val dateFormat = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())

        return apps
            .filter { it.packageName != packageName } // never list ourselves
            .mapNotNull { appInfo ->
                try {
                    val enabled = appInfo.enabled
                    val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    val isProtected = ProtectedPackages.isProtected(appInfo.packageName)

                    val original = prefs.getOriginalEnabledState(appInfo.packageName)
                    if (original == null) {
                        prefs.recordOriginalEnabledState(appInfo.packageName, enabled)
                    } else if (original != enabled) {
                        val label = appInfo.loadLabel(pm)?.toString() ?: appInfo.packageName
                        val timestamp = dateFormat.format(Date())
                        val action = if (enabled) "re-enabled" else "disabled"
                        prefs.appendChangeHistory("$timestamp: $label was $action (outside AURA)")
                        prefs.recordOriginalEnabledState(appInfo.packageName, enabled) // new baseline
                    }

                    SystemAppEntry(
                        packageName = appInfo.packageName,
                        label = appInfo.loadLabel(pm)?.toString() ?: appInfo.packageName,
                        icon = try { appInfo.loadIcon(pm) } catch (_: Exception) { null },
                        isEnabled = enabled,
                        isSystemApp = isSystem,
                        isProtected = isProtected,
                    )
                } catch (_: Exception) {
                    null
                }
            }
            .sortedWith(compareBy({ !it.isEnabled }, { it.label.lowercase() }))
    }

    private fun openAppInfo(packageName: String) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (_: Exception) {
            // Device doesn't expose a details screen for this package; no safe fallback exists.
        }
    }
}
