package com.auratv.vibrantglass.settings

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.auratv.vibrantglass.R
import com.auratv.vibrantglass.apps.AppInfo

class ApplicationsAdapter(
    private val isPinned: (AppInfo) -> Boolean,
    private val onToggle: (AppInfo) -> Unit,
) : RecyclerView.Adapter<ApplicationsAdapter.ViewHolder>() {

    private val items = mutableListOf<AppInfo>()

    fun submitList(newItems: List<AppInfo>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_applications_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = items[position]
        holder.icon.setImageDrawable(app.icon ?: holder.icon.context.getDrawable(R.drawable.ic_placeholder_app))
        holder.label.text = app.label
        holder.pinButton.text = if (isPinned(app)) "Unpin" else "Pin"
        holder.pinButton.setOnClickListener {
            onToggle(app)
            notifyItemChanged(holder.bindingAdapterPosition)
        }
    }

    override fun getItemCount(): Int = items.size

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.rowIcon)
        val label: TextView = view.findViewById(R.id.rowLabel)
        val pinButton: Button = view.findViewById(R.id.pinToggleButton)
    }
}
